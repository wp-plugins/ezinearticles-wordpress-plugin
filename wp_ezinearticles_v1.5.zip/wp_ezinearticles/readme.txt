=== EzineArticles WordPress Plugin ===
Contributors: EzineArticles.com
Donate link: http://EzineArticles.com/
Tags: submission, article marketing, ezine, ezinearticles
Requires at least: 2.7
Tested up to: 2.9.2


== Description ==

The EzineArticles WordPress Plugin allows you to submit your high quality, original WordPress posts to EzineArticles.com, 
as well as monitor their review status right from the WordPress administration interface!

== Installation ==

1. Upload `wp_ezinearticles` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Once activate, go to the new EzineArticles menu in the sidebar and click Options to enter your EzineArticles API Key, Username and Password.

1, 2, 3: Installation Is Complete!


== ChangeLog ==

= 1.5 =

* Added the ability to choose a resource box.  The text can be tweaked inside of WordPress before the article is submitted.
* Users can now validate their articles to check for content not allowed by EzineArticles before they submit.
* Users can submit without posting to WordPress by pushing the submit button on the EzineArticles tab.
* Added version checks to check for the correct php version and the correct WordPress version when installing.
* Bugfixes